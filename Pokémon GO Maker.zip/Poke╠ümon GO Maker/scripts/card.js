var card = 
{
	width:739,height:1521,

	imageRotation:0,

	background:new Img("./images/card_background.jpg"),
	image:new Img(""),
	pen_icon:new Img("./images/pen_icon.png"),
	stardust_icon:new Img("./images/stardust_icon.png"),
	candy_icon:new Img("./images/candy_icon.png"),

	texts:new Array(),
	
	cp:new Input("cp",560),
	name:new Input("name",550),
	hp:new Input("hp",300),
	type:new Input("type",220),
	weight:new Input("weight",170),
	height_stat:new Input("height_stat",170),
	stardust:new Input("stardust",270),
	candy:new Input("candy",270),
	powerup_stardust:new Input("powerup_stardust",130),
	powerup_candy:new Input("powerup_candy",130),

}